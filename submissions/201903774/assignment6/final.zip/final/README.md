# 6th Assignment: Real Usage and Final Report  
**Project: BonCahier AI — 수업 자료 자동 요약·번역 도구**

- 과목명: 영어분석을위한기계학습  
- 학번: 201903774  
- 이름: 한형준  
- 전공: 언어인지과학과  
- 제출일: 2025-12-06
 

이 README는 **final.zip 안에 포함된 코드 구조와 실행 방법**,  
그리고 **Assignment 3–6 전체 흐름에서 이 프로젝트가 어떤 역할을 하는지**를 정리한 문서입니다.  

---

## 1. 프로젝트 개요

현대 대학 수업에서는 여러 과목에서 PPT/PDF 강의 자료가 대량으로 제공되며,  
시험 기간에는 짧은 시간 안에 수십~수백 장의 슬라이드를 정리해야 하는 부담이 큽니다. 특히,

- 텍스트가 많은 이론 슬라이드의 경우, **직접 요약 노트를 작성하는 데 시간이 과도하게 소요**되고
- 영어 등 **외국어로 작성된 자료는 번역과 이해를 동시에 해야 하므로 인지적 부담**이 크며
- 학기 동안 받은 자료를 시험 직전에 다시 열어 핵심만 정리하는 작업은 매우 비효율적입니다.  

이를 해결하기 위해 본 프로젝트에서는 **강의 PPT/PDF 파일을 입력으로 받아**:

1. 페이지/슬라이드 단위 텍스트 추출  
2. KoBART 기반 한국어 요약  
3. (옵션) 영어 ↔ 한국어 번역  
4. 결과를 Markdown 형식의 “요약 노트”로 저장  

까지 한 번에 수행하는 CLI 도구 **“BonCahier AI”**를 설계·구현했습니다.  

---

## 2. Assignment 3–6와의 연결

이 프로젝트는 아래와 같이 이전 과제들과 자연스럽게 이어집니다.  

| Assignment | 역할 |
|-----------|------|
| Assignment 3 (Project Proposal) | 문제 정의 및 서비스 아이디어 기획 |
| Assignment 4 (Data Collection & Analysis) | 한글/영어 뉴스 요약 데이터 수집 및 EDA |
| Assignment 5 (Model Training & Evaluation) | KoBART 한국어 뉴스 요약 모델 미세조정 및 ROUGE 평가 |
| **Assignment 6 (Real Usage & Final Report)** | **학습한 모델을 실제로 사용할 수 있는 서비스(도구)로 구현, 5회 이상 실사용, 보고서 작성** |

- Assignment 4에서는 **네이버 뉴스 한국어 요약 데이터**를 중심으로 데이터 분포·길이·카테고리 등을 분석했고,  
- Assignment 5에서는 `gogamza/kobart-base-v2`를 기반으로 **KoBART 한국어 요약 모델을 미세조정**하여 ROUGE 지표 개선을 목표로 했습니다.  
- Assignment 6인 현재 단계에서는 위에서 학습한 모델을 **`boncahier_service.py`라는 CLI 서비스**로 감싸 실제 강의 자료에 적용하고,  
  그 결과를 **report.pdf**와 샘플 요약 파일로 정리했습니다.

---

## 3. 디렉터리 구조 (final.zip)

`final.zip`을 풀면 다음과 같은 구조를 갖습니다.  

```text
final/
├── boncahier_service.py         # 강의 자료 요약·번역 CLI 메인 스크립트
├── 6thAssignment.ipynb          # Assignment 6 실험 및 실행 예시 Colab 노트북
├── requirements.txt             # 서비스 실행에 필요한 Python 패키지 목록
│
├── models/
│   └── .gitkeep                 # fine-tuned KoBART 모델을 둘 디렉터리(예: kobart_ko_news/)
│
├── sample_outputs/              # Assignment 6에서 실제 실행하여 생성된 요약 결과들
│   ├── summary_201903774...pptx_20251206-....md
│   ├── summary_2025fall_7.DNN과 RNN_20251206-....md
│   ├── summary_ml4e-lecture-week13_20251206-....md
│   ├── summary_NLP_Lec3&4_NLP_TM_slides_20251206-....md
│   └── summary_PythonReview_20251206-....md
│
├── screenshots/                 # 5회 실사용 시 Colab/CLI 실행 화면 스크린샷
│   ├── Premiere1.png  ...  Troisieme2.png
│
├── training_notebooks/          # Assignment 5: KoBART 학습 및 평가 재현용 노트북
│   ├── training.ipynb
│   ├── evaluation.ipynb
│   └── inference.ipynb
│
└── uploaded_textbooks/          # Assignment 6에서 실제로 사용한 5개의 강의 자료(PDF/PPTX)
    ├── 201903774...발표자료.pptx
    ├── 201903774...교재 일부.pdf
    ├── 2025fall_7.DNN과 RNN.pdf
    ├── NLP_Lec3&4_NLP_TM_slides.pdf
    └── PythonReview.pdf
```

> 실제 평가 시 **서비스 실행에 직접 필요한 것은**  
> `boncahier_service.py`, `requirements.txt`, `models/kobart_ko_news/ (선택)`, 그리고 입력 파일(PDF/PPTX)입니다.  
> 나머지 폴더들은 **학습 재현 및 실사용 증빙(보고서/스크린샷)** 용으로 포함되어 있습니다.  

---

## 4. 실행 환경 준비

### 4.1 Google Colab + Google Drive (권장)

1. Google Drive 마운트

```python
from google.colab import drive
drive.mount('/content/drive')
```

2. 필수 라이브러리 설치 (`requirements.txt`와 동일)

```bash
!pip install -q transformers sentencepiece torch pymupdf python-pptx tqdm sacremoses
```

- `torch` – PyTorch (Colab의 GPU 환경 사용 권장)  
- `transformers`, `sentencepiece` – KoBART 및 번역 모델  
- `pymupdf` – PDF 텍스트 추출  
- `python-pptx` – PPTX 텍스트 추출  

3. `final.zip` 업로드 & 압축 해제

```bash
%cd /content
!unzip -o final.zip -d /content
%cd /content/final
```

### 4.2 fine-tuned KoBART 모델 준비 (선택)

Assignment 5에서 학습한 모델 디렉터리 예시는 다음과 같습니다.  

```text
/content/drive/MyDrive/boncahier/models/kobart_ko_news/
```

이 디렉터리를 `boncahier_service.py`에서 `--model-dir` 인자로 넘기면,  
**뉴스 데이터로 미세조정된 KoBART 모델**을 사용합니다.

- Colab 예시:

```python
MODEL_DIR = "/content/drive/MyDrive/boncahier/models/kobart_ko_news"
OUTPUT_DIR = "/content/outputs"
INPUT_PATH = "/content/final/uploaded_textbooks/ml4e-lecture-week13.pdf"
```

```bash
!python /content/final/boncahier_service.py   -i "{INPUT_PATH}"   --model-dir "{MODEL_DIR}"   -o "{OUTPUT_DIR}"
```

> 만약 `--model-dir`에 유효한 디렉터리가 없으면,  
> 자동으로 HuggingFace Hub의 `gogamza/kobart-base-v2`를 다운로드하여 사용합니다.  

---

## 5. 사용 방법 (CLI 인터페이스)

### 5.1 기본 실행

```bash
python boncahier_service.py   -i path/to/lecture_slides.pdf   --model-dir models/kobart_ko_news   -o outputs
```

- `-i / --input` : 입력 파일 경로 (`.pdf` 또는 `.pptx`)  
- `-o / --output-dir` : 결과 Markdown 파일을 저장할 디렉터리 (기본값: `outputs/`)  
- `--model-dir` : fine-tuned KoBART 모델 디렉터리 (선택)  
- `--model-name` : 모델 디렉터리가 없을 때 사용할 HF 모델 ID (기본: `gogamza/kobart-base-v2`)

성공적으로 실행되면:

```text
outputs/summary_{파일이름}_{타임스탬프}.md
```

형식의 요약 결과 파일이 생성됩니다.  

### 5.2 페이지/슬라이드 범위 지정

긴 강의 자료의 일부분만 요약하고 싶을 때는  
`--start-page`, `--end-page` 옵션을 사용할 수 있습니다. (1부터 시작하는 인덱스)

```bash
# 3~10 페이지/슬라이드만 요약
python boncahier_service.py   -i path/to/file.pdf   --model-dir models/kobart_ko_news   --start-page 3   --end-page 10   -o outputs
```

```bash
# 5번 페이지만 요약
python boncahier_service.py   -i path/to/file.pptx   --model-dir models/kobart_ko_news   --start-page 5   --end-page 5   -o outputs
```

범위를 지정하지 않으면 전체(1~N)를 자동으로 처리합니다.

### 5.3 번역 단계 비활성화

영어 ↔ 한국어 번역을 사용하지 않고,  
**한국어 텍스트만 요약**하거나 번역 없는 간단 요약만 보고 싶으면 `--no-translate`를 사용합니다.

```bash
python boncahier_service.py   -i path/to/file.pdf   --model-dir models/kobart_ko_news   --no-translate   -o outputs
```

### 5.4 내부 동작 요약

`boncahier_service.py`는 대략 다음과 같은 순서로 동작합니다.  

1. **텍스트 추출**
   - PDF: `PyMuPDF(fitz)`로 페이지별 텍스트 추출  
   - PPTX: `python-pptx`로 슬라이드 내 텍스트 박스를 모아서 하나의 문자열로 병합  

2. **언어 감지 (간단 heuristic)**
   - 텍스트에 한글 유니코드(`\uac00–\ud7a3`)가 포함되어 있으면 “한국어”,  
     그렇지 않으면 “비한국어(주로 영어)”로 간주  

3. **번역 (옵션)**
   - 비한국어로 추정되는 경우  
     → `Helsinki-NLP/opus-mt-tc-big-en-ko`로 **영→한 번역** 후 KoBART로 요약  
   - 한국어 요약 결과는 필요 시  
     → `Helsinki-NLP/opus-mt-ko-en`으로 **한→영 번역**  

4. **요약**
   - KoBART 기반 모델로 `max_source_length=512`, `max_target_length=128`, `num_beams=4` 설정으로 요약 수행  

5. **Markdown 저장**
   - 각 유닛(Unit)에 대해  
     - 원본 텍스트  
     - 한국어 요약  
     - (옵션) 영어 번역 요약  
     - 비고(번역 수행 여부, 오류 메시지 등)  
   - 을 포함하는 결과 파일 `summary_*.md` 생성

---

## 6. 실제 사용 결과 요약 (5회 이상)

Assignment 6에서는 실제 강의 자료 5개를 대상으로 도구를 사용해 보았습니다.  

| 회차 | 입력 파일 | 유형 | 언어 | 주요 목적 | 관찰/소감 (요약) |
|------|-----------|------|------|-----------|-------------------|
| 1 | 201903774 한형준 15주 발표자료.pptx | PPTX | 한국어 | 요약 | 내용이 많은 발표 슬라이드에서는 핵심 키워드 중심 요약이 비교적 잘 작동함 |
| 2 | ml4e-lecture-week13.pdf | PDF | 영어 | 요약+번역 | 영→한 번역 품질이 낮고, 웹페이지 텍스트로 잘못 번역되는 등 심각한 오류 발생 |
| 3 | 2025fall_7.DNN과 RNN.pdf | PDF | 한국어 | 요약+번역 | 한→영 번역에도 오류가 있으나, 영→한보다는 상대적으로 나은 편 |
| 4 | NLP_Lec3&4_NLP_TM_slides.pdf | PDF | 영어 | 요약 | 번역을 끄고 사용 시, Text Mining 관련 핵심 개념을 어느 정도 잡아주지만 전처리 필요성이 큼 |
| 5 | PythonReview.pdf | PDF | 영어+코드 | 요약 | 프로그래밍 코드와 특수문자가 많은 슬라이드는 텍스트 추출/요약 모두에서 오류가 다수 발생 |

각 회차에 대한 **자세한 예시는** `sample_outputs/summary_*.md` 파일과  
`report.pdf`의 본문 및 부록에 포함된 스크린샷/로그 발췌를 통해 확인할 수 있습니다.  

---

## 7. 한계점 및 향후 개선 방향

보고서에서 정리한 바와 같이, 본 프로젝트에는 다음과 같은 한계가 있습니다.  

- **도메인 미스매치**  
  - 학습 데이터가 주로 뉴스 기사이기 때문에, 실제 강의 슬라이드의 레이아웃·문체와는 차이가 있습니다.
- **영→한 번역 품질 문제**  
  - `en→ko → 요약 → ko→en`과 같은 파이프라인 구조에서  
    특히 영→한 번역이 부정확할 경우, 전체 요약 품질이 크게 저하됩니다.
- **텍스트 추출 품질 의존성**  
  - 표, 이미지, 수식, 코드, 링크 등이 많은 슬라이드는 텍스트 추출이 깨지거나 섞여 들어갈 수 있으며,  
    이 경우 요약 모델이 의미 있는 출력을 내기 어렵습니다.

향후 개선 방향으로는:

- **강의 슬라이드 전용 데이터셋 구축** 후 KoBART를 슬라이드 도메인에 특화된 모델로 재학습  
- **Web UI(Streamlit/Flask 등)**를 활용한 GUI 기반 서비스 확장  
- 더 나은 품질의 번역 모델 적용 또는 외부 번역 API(DeepL, Google Translate 등)와의 연동  
- 영어 데이터/모델 재선정 및 전처리 파이프라인 고도화  

등을 고려할 수 있습니다.  

---

## 8. Assignment 6 관점에서의 제출 요약

- **모델 서비스화 (30%)**  
  - `boncahier_service.py`를 통해 학습된 KoBART 모델을  
    실제로 실행 가능한 CLI 기반 요약·번역 서비스 형태로 구현했습니다.  
- **실제 사용 (30%)**  
  - 서로 다른 5개의 실제 강의 자료(PPT/PDF)에 대해 도구를 적용하고,  
    결과를 `sample_outputs/`, `screenshots/`, `report.pdf`에 정리했습니다.  
- **최종 보고서 (30%)**  
  - `report.pdf`에는 프로젝트 개요, Assignment 3–5 진행 과정,  
    서비스 구조, 5회 사용 기록, 한계 및 개선 방향을 포함했습니다.  
- **실행 가능성 (10%)**  
  - `requirements.txt`와 README의 실행 예시를 통해,  
    최소 설정 변경만으로 Colab에서 바로 실행 가능한 형태를 목표로 했습니다.  

이 README는 평가자가 **final.zip의 구조와 실행 방법을 빠르게 이해하고**,  
`report.pdf`와 `sample_outputs/`를 함께 보면서 전체 프로젝트 흐름을 추적할 수 있도록 작성되었습니다.
