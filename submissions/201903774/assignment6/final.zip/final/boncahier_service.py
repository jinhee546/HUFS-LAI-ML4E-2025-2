#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
BonCahier AI — Lecture Summarization & Translation CLI Service
Assignment 6 (Real Usage & Final Report)

이 스크립트는 PDF/PPTX 강의 자료를 입력으로 받아,
1) 슬라이드/페이지 단위 텍스트 추출,
2) KoBART 기반 한국어 요약,
3) (선택) 영어↔한국어 번역
을 수행하고 Markdown 형식으로 결과를 저장합니다.

또한, --start-page / --end-page 옵션을 통해
전체가 아닌 특정 페이지/슬라이드 범위만 선택적으로 처리할 수 있습니다.

영→한 번역 모델은 기존에 자주 인용되던 "Helsinki-NLP/opus-mt-en-ko"가
HuggingFace 공식 모델 리스트에 없어서, 실제 존재하는
"Helsinki-NLP/opus-mt-tc-big-en-ko"를 사용합니다.
"""

import argparse
import os
import sys
import re
import pathlib
import datetime
from typing import List, Dict, Optional

HANGUL_RE = re.compile(r"[\uac00-\ud7a3]")


def is_korean(text: str) -> bool:
    """간단한 한글 포함 여부로 한국어 텍스트인지 추정."""
    return bool(HANGUL_RE.search(text or ""))


# ==============================
# 1. 텍스트 추출 유틸리티
# ==============================

def extract_from_pdf(path: str) -> List[Dict[str, str]]:
    """PyMuPDF를 사용해 PDF 각 페이지에서 텍스트를 추출합니다."""
    try:
        import fitz  # PyMuPDF
    except ImportError as e:
        raise ImportError(
            "pymupdf(fitz)가 설치되어 있지 않습니다. `pip install pymupdf` 후 다시 실행해주세요."
        ) from e

    doc = fitz.open(path)
    units: List[Dict[str, str]] = []

    for i, page in enumerate(doc):
        text = page.get_text("text") or ""
        text = text.strip()
        if not text:
            continue
        units.append(
            {
                "id": f"page_{i+1}",
                "kind": "page",
                "text": text,
            }
        )

    doc.close()
    return units


def extract_from_pptx(path: str) -> List[Dict[str, str]]:
    """python-pptx를 사용해 PPTX 각 슬라이드에서 텍스트를 추출합니다."""
    try:
        from pptx import Presentation
    except ImportError as e:
        raise ImportError(
            "python-pptx가 설치되어 있지 않습니다. `pip install python-pptx` 후 다시 실행해주세요."
        ) from e

    prs = Presentation(path)
    units: List[Dict[str, str]] = []

    for i, slide in enumerate(prs.slides):
        texts = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text:
                texts.append(shape.text)
        merged = "\n".join(t.strip() for t in texts if t and t.strip())
        merged = merged.strip()
        if not merged:
            continue
        units.append(
            {
                "id": f"slide_{i+1}",
                "kind": "slide",
                "text": merged,
            }
        )

    return units


# ==============================
# 2. 요약 & 번역 모델 로딩
# ==============================

def load_summarization_model(model_dir: str, model_name: str):
    """KoBART 요약 모델을 로드합니다.

    - model_dir 디렉터리가 존재하면 거기에 저장된 (fine-tuned) 모델을 사용
    - 그렇지 않으면 model_name(HuggingFace Hub ID)로부터 다운로드
    """
    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    except ImportError as e:
        raise ImportError(
            "transformers 및 torch가 필요합니다. `pip install transformers torch sentencepiece` 후 실행해주세요."
        ) from e

    if model_dir and os.path.isdir(model_dir):
        source = model_dir
    elif model_name:
        source = model_name
    else:
        source = "gogamza/kobart-base-v2"

    print(f"[Summarization] Loading model from: {source}")
    tokenizer = AutoTokenizer.from_pretrained(source, use_fast=False)
    model = AutoModelForSeq2SeqLM.from_pretrained(source)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    model.eval()

    return tokenizer, model, device, source


def summarize_text(tokenizer, model, device, text: str,
                   max_source_length: int = 512,
                   max_target_length: int = 128,
                   num_beams: int = 4) -> str:
    """KoBART를 사용하여 한 문단을 한국어로 요약합니다."""
    import torch

    text = (text or "").strip()
    if not text:
        return ""

    inputs = tokenizer(
        text,
        max_length=max_source_length,
        padding="max_length",
        truncation=True,
        return_tensors="pt",
    )
    inputs = {k: v.to(device) for k, v in inputs.items()}
    inputs.pop("token_type_ids", None)

    with torch.no_grad():
        generated = model.generate(
            **inputs,
            max_length=max_target_length,
            num_beams=num_beams,
            no_repeat_ngram_size=3,
            early_stopping=True,
        )

    summary = tokenizer.decode(generated[0], skip_special_tokens=True)
    return summary.strip()


def _load_translation_model(direction: str, cache: dict):
    """direction: 'en-ko' 또는 'ko-en'"""
    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    except ImportError as e:
        raise ImportError(
            "번역 기능을 사용하려면 transformers 및 torch가 필요합니다."
        ) from e

    if direction in cache:
        return cache[direction]

    if direction == "en-ko":
        # 실제 존재하는 영→한 모델
        model_name = "Helsinki-NLP/opus-mt-tc-big-en-ko"
    elif direction == "ko-en":
        model_name = "Helsinki-NLP/opus-mt-ko-en"
    else:
        raise ValueError(f"지원하지 않는 번역 방향: {direction}")

    print(f"[Translation] Loading model: {model_name} (direction={direction})")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    model.eval()

    cache[direction] = (tokenizer, model, device)
    return cache[direction]


def translate(text: str, direction: str, cache: dict,
              max_length: int = 512) -> str:
    import torch

    text = (text or "").strip()
    if not text:
        return ""

    tokenizer, model, device = _load_translation_model(direction, cache)
    inputs = tokenizer(
        text,
        max_length=max_length,
        truncation=True,
        return_tensors="pt",
    )
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_length=max_length,
            num_beams=4,
            early_stopping=True,
        )

    out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return out.strip()


from typing import Optional

def process_file(
    input_path: pathlib.Path,
    output_dir: pathlib.Path,
    model_dir: str,
    model_name: str,
    max_source_length: int,
    max_target_length: int,
    num_beams: int,
    disable_translation: bool = False,
    start_page: Optional[int] = None,
    end_page: Optional[int] = None,
) -> pathlib.Path:
    """단일 PDF/PPTX 파일을 처리하고 결과 markdown 파일 경로를 반환.

    start_page, end_page는 1-based index로 페이지/슬라이드 범위를 지정합니다.
    둘 다 None이면 전체 범위를 처리합니다.
    """

    ext = input_path.suffix.lower()
    if ext == ".pdf":
        units = extract_from_pdf(str(input_path))
    elif ext == ".pptx":
        units = extract_from_pptx(str(input_path))
    else:
        raise ValueError("현재는 .pdf 및 .pptx 파일만 지원합니다.")

    if not units:
        raise RuntimeError("입력 파일에서 추출된 텍스트가 없습니다.")

    total_units = len(units)

    if start_page is None and end_page is None:
        selected_units = units
        selected_range_str = f"1-{total_units} (전체)"
    else:
        if start_page is None and end_page is not None:
            start_page = 1
        if start_page is not None and end_page is None:
            end_page = start_page

        if start_page < 1 or start_page > total_units:
            raise ValueError(f"--start-page 값이 유효 범위를 벗어났습니다: {start_page} (총 {total_units}페이지/슬라이드)")
        if end_page < 1 or end_page > total_units:
            raise ValueError(f"--end-page 값이 유효 범위를 벗어났습니다: {end_page} (총 {total_units}페이지/슬라이드)")
        if start_page > end_page:
            raise ValueError(f"--start-page({start_page})가 --end-page({end_page})보다 클 수 없습니다.")

        selected_units = units[start_page - 1:end_page]
        selected_range_str = f"{start_page}-{end_page} (총 {len(selected_units)}개)"

    tokenizer, model, device, source = load_summarization_model(model_dir, model_name)

    translation_cache: dict = {}
    use_translation = not disable_translation

    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_path = output_dir / f"summary_{input_path.stem}_{timestamp}.md"

    with out_path.open("w", encoding="utf-8") as f:
        f.write(f"# BonCahier AI Summary — {input_path.name}\n\n")
        f.write(f"- 생성 시각: {datetime.datetime.now().isoformat(timespec='seconds')}\n")
        f.write(f"- 원본 파일 경로: {input_path.resolve()}\n")
        f.write(f"- 요약 모델: {source}\n")
        if use_translation:
            f.write("- 번역 모델: Helsinki-NLP/opus-mt-tc-big-en-ko / opus-mt-ko-en (필요 시 자동 로드)\n")
        f.write(f"- 처리 대상 페이지/슬라이드 범위: {selected_range_str}\n")
        f.write(f"- 전체 페이지/슬라이드 수: {total_units}\n")
        f.write("\n---\n\n")


        for idx, unit in enumerate(selected_units, start=1):
            raw_text = unit.get("text", "").strip()
            if not raw_text:
                continue

            korean_like = is_korean(raw_text)
            source_lang = "ko" if korean_like else "en/other"

            f.write(f"## Unit {idx} — {unit.get('id')} ({unit.get('kind')})\n\n")
            f.write("### 원본 텍스트\n\n")
            f.write("```\n")
            f.write(raw_text)
            f.write("\n```\n\n")


            note_lines = []
            text_for_summary = raw_text

            if use_translation and not korean_like:
                try:
                    text_for_summary = translate(raw_text, "en-ko", translation_cache)
                    note_lines.append("※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.")
                except Exception as e:
                    note_lines.append(f"※ 번역(en→ko) 중 오류 발생: {e!r} — 원문 그대로 요약을 시도합니다.")
                    text_for_summary = raw_text

            try:
                summary_ko = summarize_text(
                    tokenizer,
                    model,
                    device,
                    text_for_summary,
                    max_source_length=max_source_length,
                    max_target_length=max_target_length,
                    num_beams=num_beams,
                )
            except Exception as e:
                summary_ko = ""
                note_lines.append(f"※ 요약 중 오류 발생: {e!r}")

            f.write("### 한국어 요약 결과\n\n")
            if summary_ko:
                f.write(summary_ko + "\n\n")
            else:
                f.write("_요약 결과를 생성하지 못했습니다._\n\n")


            if use_translation and summary_ko:
                try:
                    summary_en = translate(summary_ko, "ko-en", translation_cache)
                    f.write("### (옵션) 영어 번역 요약\n\n")
                    f.write(summary_en + "\n\n")
                except Exception as e:
                    note_lines.append(f"※ 요약 영어 번역(ko→en) 중 오류 발생: {e!r}")

            if note_lines:
                f.write("### 비고\n\n")
                for line in note_lines:
                    f.write(f"- {line}\n")
                f.write("\n")


            f.write("\n---\n\n")


    return out_path


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="BonCahier AI — Lecture Summarization & Translation CLI"
    )
    parser.add_argument(
        "-i", "--input",
        required=True,
        help="입력 강의 자료 파일 경로 (.pdf / .pptx)",
    )
    parser.add_argument(
        "-o", "--output-dir",
        default="outputs",
        help="요약 Markdown 파일을 저장할 디렉터리 (기본값: outputs)",
    )
    parser.add_argument(
        "--model-dir",
        default="models/kobart_ko_news",
        help="fine-tuning된 KoBART 모델 디렉터리 (없으면 model-name을 사용하여 다운로드)",
    )
    parser.add_argument(
        "--model-name",
        default="gogamza/kobart-base-v2",
        help="HuggingFace Hub 상의 기본 모델 이름 (기본값: gogamza/kobart-base-v2)",
    )
    parser.add_argument(
        "--max-source-length",
        type=int,
        default=512,
        help="입력 텍스트 최대 토큰 길이 (기본: 512)",
    )
    parser.add_argument(
        "--max-target-length",
        type=int,
        default=128,
        help="요약 텍스트 최대 토큰 길이 (기본: 128)",
    )
    parser.add_argument(
        "--num-beams",
        type=int,
        default=4,
        help="beam search 개수 (기본: 4)",
    )
    parser.add_argument(
        "--no-translate",
        action="store_true",
        help="번역 단계를 비활성화합니다 (요약만 수행).",    )
    parser.add_argument(
        "--start-page",
        type=int,
        default=None,
        help="처리할 시작 페이지/슬라이드 (1-based). 지정하지 않으면 처음부터.",
    )
    parser.add_argument(
        "--end-page",
        type=int,
        default=None,
        help="처리할 마지막 페이지/슬라이드 (1-based, 포함). 지정하지 않으면 끝까지.",
    )

    args = parser.parse_args(argv)

    input_path = pathlib.Path(args.input)
    if not input_path.exists():
        parser.error(f"입력 파일을 찾을 수 없습니다: {input_path}")

    output_dir = pathlib.Path(args.output_dir)

    try:
        out_path = process_file(
            input_path=input_path,
            output_dir=output_dir,
            model_dir=args.model_dir,
            model_name=args.model_name,
            max_source_length=args.max_source_length,
            max_target_length=args.max_target_length,
            num_beams=args.num_beams,
            disable_translation=args.no_translate,
            start_page=args.start_page,
            end_page=args.end_page,
        )
    except Exception as e:
        print(f"[오류] 처리 중 예외가 발생했습니다: {e!r}", file=sys.stderr)
        sys.exit(1)

    print(f"✅ 요약이 완료되었습니다. 결과 파일: {out_path}")


if __name__ == "__main__":
    main()
