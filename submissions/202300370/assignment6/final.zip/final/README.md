final.ipynb를 열어 전체를 run 한 뒤,
업로드 파일을 요구할 시 stance_examples1.cv를 업로드

가중치 저장 구글 드라이브 위치:  https://drive.google.com/drive/folders/1lrVAAxNIcdFhe7BdV6GU-QR12Et_PiKb?usp=sharing

가장 아래쪽에서 input을 요구.

'enter the topic: '이 떴을 때 주제를 기입하고,
'enter the sources: '가 떴을 때 자료를 복사 붙여넣기 하면 됨.
모든 자료를 다 넣었다면 'end'라고 작성하면 종료.

아래에 나오는 결과를 보고 사용.