# Assignment 6

## 실행방법

### 시스템 요구 사항

* Window 운영체제
* Python 설치
* 모델 가중치 용량이 너무 커서 업로드가 안되는 관계로 final 폴더 내부에 `instruction\_classifier\_model .txt` 파일을 만들었으니, 이 파일에 접속하여 해당 링크에서 final 파일을 다운로드 부탁드립니다.
* 다운로드 후 폴더 구조 (필수)

final/

├── input\_data/

│ ├── 2015\_miraen.txt

│ ├── 2015\_miraen\_sin.txt

│ ├── 2022\_miraen.txt

│ ├── 2022\_visang\_parkh.txt

│ ├── 2022\_visang\_parky.txt

│ ├── document\_to\_process.txt

│ ├── sejong1.txt

│ ├── sejongkr\_1A.txt

├── instruction\_classifier\_model/

│ ├── config.json

│ ├── model.safetensors

│ ├── special\_tokens\_map.json

│ ├── spiece.model

│ ├── tokenizer.json

│ └── tokenizer\_config.json

├─ requirements.txt

├─ txb\_inference.py

└─ README.md



### 실행 단계

1. CMD를 열고 프로젝트 폴더로 이동:
   cd C:\\final
2. 'venv'라는 이름의 가상 환경 생성:
   python -m venv venv
3. 가상 환경 활성화 (Windows CMD 명령어):
   venv\\Scripts\\activate
4. 필요한 라이브러리 설치:
   pip install -r requirements.txt
5. 도구 실행
   **실행 시 처리하고자 하는 txt 파일이 input\_data 폴더 안에 미리 저장되어 있어야 함.**

* 실행 형식:
  python txb\_inference.py input\_data\\{파일명}.txt --model-dir instruction\_classifier\_model

6. 결과 확인



##### Anaconda prompt 사용시

1. Anaconda prompt를 열고 프로젝트 폴더로 이동:
   cd C:\\final
2. 새 환경 생성:
   conda create --name kobert\_env python=3.10
3. 환경 활성화:
   conda activate kobert\_env
4. 도구 실행에 필요한 라이브러리 설치:
   pip install -r requirements.txt
5. 도구 실행:
   python txb\_inference.py input\_data\\{파일명}.txt --model\_dir instruction\_classifier\_model
   **처리할 txt파일이 input\_data 폴더 안에 미리 저장되어 있어야 함.**
6. 결과 확인
7. 종료:
   conda deactivate
