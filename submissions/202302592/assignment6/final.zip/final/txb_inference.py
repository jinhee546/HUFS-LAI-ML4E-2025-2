# 이 파일은 /content/txb_inference.py 파일로 저장됩니다.
# Note: 이 파일은 실행 시 모든 함수와 변수를 내부적으로 재정의합니다.

import os
import torch
import argparse
import re
import sys
from transformers import AutoTokenizer, BertForSequenceClassification

# ----------------------------------------------------------------------
# 모델 로드 및 추론 로직 (Colab의 전역 변수와 독립적으로 실행됨)
# ----------------------------------------------------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
tokenizer = None
model = None

def load_model(model_dir: str):
    """모델과 토크나이저를 메모리에 로드합니다."""
    # (Cell 1의 load_model과 동일한 내용)
    global tokenizer, model
    try:
        print(f"모델 로드 중: {model_dir}")
        tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
        model = BertForSequenceClassification.from_pretrained(model_dir, local_files_only=True)
        model.to(device)
        model.eval()
        print("✅ 모델 로드 성공.")
        return True
    except Exception as e:
        print(f"❌ 오류: 모델 로드 실패. '{model_dir}' 경로를 확인하세요.")
        return False

def is_instruction(sentence: str) -> int:
    """ 주어진 문장이 지시문인지 (1) 아닌지 (0) 판별합니다. """
    # (Cell 1의 is_instruction과 동일한 내용)
    global tokenizer, model
    if model is None: return 0 
    if not sentence or len(sentence.strip()) < 3: return 0
    
    encoding = tokenizer.encode_plus(
        sentence, return_tensors="pt", truncation=True, padding="max_length", 
        max_length=64, add_special_tokens=True, return_attention_mask=True
    )
    input_ids = encoding["input_ids"].to(device)
    mask = encoding["attention_mask"].to(device)
    
    with torch.no_grad():
        outputs = model(input_ids, attention_mask=mask)
        prediction = torch.argmax(outputs.logits, dim=1).item()
    return prediction

# ----------------------------------------------------------------------
# CLI 메인 함수 (CLI 실행 시 호출됨)
# ----------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="KoBERT 기반 TXT 파일 지시문 추출 CLI 도구"
    )
    # (argparse 설정은 이전과 동일)
    parser.add_argument("input_file", type=str, help="처리할 입력 TXT 파일 경로")
    parser.add_argument("--model_dir", type=str, default="./instruction_classifier_model", help="학습된 모델 폴더 경로")
    args = parser.parse_args()

    # 1. 모델 로드 (CLI 실행 시 매번 다시 로드)
    if not load_model(args.model_dir):
        sys.exit(1)

    input_file_path = args.input_file
    
    # 2. 파일 읽기
    try:
        with open(input_file_path, 'r', encoding='utf-8') as f:
            text = f.read()
    except FileNotFoundError:
        print(f"\n❌ 오류: 입력 파일 '{input_file_path}'를 찾을 수 없습니다.")
        sys.exit(1)

    # 3. 문장 분리 및 추론
    sentences = re.split(r'([.?!])\s+', text)
    processed_sentences = []
    extracted_instructions = []
    
    for i in range(0, len(sentences), 2):
        sentence = sentences[i].strip()
        if not sentence: continue
        if i + 1 < len(sentences):
            sentence += sentences[i+1].strip()
        
        processed_sentences.append(sentence)

        if is_instruction(sentence) == 1:
            extracted_instructions.append(sentence)

    # 4. 결과 출력
    print("\n[ 최종 추출 결과 ]")
    print(f"총 문장 수: {len(processed_sentences)}")
    print(f"추출된 지시문 수: {len(extracted_instructions)}")
    print("-" * 30)

    if extracted_instructions:
        for i, instruction in enumerate(extracted_instructions):
            print(f"  {i+1}. {instruction}")
    else:
        print("추출된 지시문이 없습니다.")
    print("-" * 30)


if __name__ == "__main__":
    main()
