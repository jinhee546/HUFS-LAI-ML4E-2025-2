# 이 파일은 서버 시작 시 모델을 직접 로드합니다.

import os
import torch
from flask import Flask, request, jsonify
import PyPDF2
import io
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

# --- 설정값 ---
MAX_LENGTH = 50
NUM_BEAMS = 4
# 사용자님의 경로를 사용합니다.
MODEL_PATH = '/content/drive/MyDrive/AIHUB_DATA/final_nmt_model_1500'
# --------------

app = Flask(__name__)

# ==========================================================
# 모델 로드 코드 (서버 실행 전에 전역 변수 model, tokenizer를 정의)
# ==========================================================
tokenizer = None
model = None
try:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if os.path.isdir(MODEL_PATH):
        tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
        model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_PATH).to(device)
        print(f"[NMT Server] 모델 로드 완료 (장치: {device})")
    else:
        print(f"[NMT Server] 오류: 모델 경로를 찾을 수 없음 ({MODEL_PATH})")
except Exception as e:
    print(f"[NMT Server] 모델 로드 중 심각한 오류 발생: {e}")
# ==========================================================

# --- API 라우트 정의 ---
@app.route('/translate_pdf', methods=['POST'])
def translate_pdf_file():
    global model, tokenizer

    if model is None:
        # 서버 콘솔에 모델 로드 오류가 출력되었을 것입니다.
        return jsonify({"error": "Model is not loaded inside the server. Check server console for errors."}), 500

    if 'pdf_file' not in request.files:
        return jsonify({"error": "No 'pdf_file' part in the request"}), 400

    file = request.files['pdf_file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file and file.filename.endswith('.pdf'):
        try:
            # PyPDF2를 사용하여 텍스트 추출
            pdf_reader = PyPDF2.PdfReader(file.stream)
            extracted_text = ""
            for page in pdf_reader.pages:
                text = page.extract_text()
                if text:
                    extracted_text += text + "\n"

            if not extracted_text.strip():
                 return jsonify({"source": file.filename, "error": "PDF file contains no readable text."}), 400

            input_text = extracted_text

            # NMT 모델 추론 로직
            inputs = tokenizer([input_text], return_tensors="pt", padding=True, truncation=True, max_length=MAX_LENGTH)
            input_ids = inputs['input_ids'].to(model.device)
            attention_mask = inputs['attention_mask'].to(model.device)

            output_ids = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_length=MAX_LENGTH,
                num_beams=NUM_BEAMS,
                do_sample=False,
            )
            translated_texts = tokenizer.batch_decode(output_ids, skip_special_tokens=True)

            return jsonify({
                 "source_filename": file.filename,
                 "source_text_chunk": input_text,
                 "translation": translated_texts[0],
                 "note": "모델 입력 길이 제한으로 인해 PDF 내용의 일부만 번역되었습니다."
             })

        except Exception as e:
            # 서버 내부 오류 발생 시 상세 메시지를 클라이언트에게 반환
            return jsonify({"error": f"서버 내부 처리 오류: {str(e)}"}), 500

    return jsonify({"error": "Invalid file type. Only PDF is supported."}), 400

@app.route('/', methods=['GET'])
def health_check():
    global model
    if model is not None:
        status = "OK"
        device = str(model.device)
    else:
        status = "Model Not Attached"
        device = "N/A"
    return jsonify({"status": status, "service": "NMT Translator", "device": device}), 200

# 서버 시작
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
